/**
* <Ordered list of Comparable objects>
*
* CSC 1351 Programming Project No 1
7
* Section 1
*
* @author Lily Yang
* @since 03/17/2024
*
*/

import java.util.Arrays;

public class aOrderedList {
    private final int SIZEINCREMENTS = 20; //size of increments for increasing ordered list
    private Comparable[] oList;            //the ordered list
    private int listSize;                  //the size of the ordered list
    private int numObjects;                //the number of objects in the ordered list

    /**
     * Constructor to initialize the ordered list
     *
     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Lily Yang
     * @since 03/17/2024
     *
     */
    
    public aOrderedList() {
        numObjects = 0;
        listSize = SIZEINCREMENTS;
        oList = new Comparable[listSize];
    }
    
    /**
     * Method to add a new object to the ordered list
     *
     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Lily Yang
     * @since 03/17/2024
     *
     */

    public void add(Comparable newObject) {
        if (numObjects == listSize) {
            resizeList();
        }

        int index = findInsertIndex(newObject);
        shiftArrayToRight(index);
        oList[index] = newObject;
        numObjects++;
    }
    
    /**
     * Method to represent the ordered list as a string
     *
     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Lily Yang
     * @since 03/17/2024
     *
     */
    
    public String toString() {
    	StringBuilder result = new StringBuilder("[");
    	for (int i = 0; i < numObjects; i++) {
    		result.append(oList[i].toString());
    		if (i < numObjects - 1) {
    			result.append(", ");
    		}
    	}
    	result.append("]");
    	return result.toString();
    }
    
    /**
     * Method to resize the list when it  reaches capacity
     *
     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Lily Yang
     * @since 03/17/2024
     *
     */
    
    private void resizeList() {
        listSize += SIZEINCREMENTS;
        oList = Arrays.copyOf(oList, listSize);
    }
    
    /**
     * Method to find the index where the new object should be inserted while maintaining the order
     *
     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Lily Yang
     * @since 03/17/2024
     *
     */

    private int findInsertIndex(Comparable newObject) {
        int index = 0;
        while (index < numObjects && oList[index].compareTo(newObject) < 0) {
            index++;
        }
        return index;
    }
    
    /**
     * Method to shift elements to the right to make space for a new object to be inserted
     *
     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Lily Yang
     * @since 03/17/2024
     *
     */

    private void shiftArrayToRight(int index) {
        for (int i = numObjects; i > index; i--) {
            oList[i] = oList[i - 1];
        }
    }
    
    /**
     * Method to delete an object from the list based on its make and year
     *
     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Lily Yang
     * @since 03/17/2024
     *
     */

    public void delete(String make, int year) {
        int index = findIndex(make, year);
        if (index != -1) {
            shiftArrayToLeft(index);
            numObjects--;
        }
    }
    
    /**
     * Method to find the index of the object to be deleted based on its make and year
     *
     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Lily Yang
     * @since 03/17/2024
     *
     */

    private int findIndex(String make, int year) {
        for (int i = 0; i < numObjects; i++) {
            Car car = (Car) oList[i];
            if (car.getMake().equals(make) && car.getYear() == year) {
                return i;
            }
        }
        return -1;
    }
    
    /**
     * Method to shift elements to the left to fill the gap left by a deleted object
     *
     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Lily Yang
     * @since 03/17/2024
     *
     */

    private void shiftArrayToLeft(int index) {
        for (int i = index; i < numObjects - 1; i++) {
            oList[i] = oList[i + 1];
        }
    }
    
    /**
     * Method to return the number of objects currently in the list
     *
     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Lily Yang
     * @since 03/17/2024
     *
     */

    public int size() {
        return numObjects;
    }
    
    /**
     * Method to get the object at the specified index in the list
     *
     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Lily Yang
     * @since 03/17/2024
     *
     */

    public Comparable get(int index) {
        return oList[index];
    }
    
    /**
     * Method to check if the list is empty
     *
     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Lily Yang
     * @since 03/17/2024
     *
     */

    public boolean isEmpty() {
        return numObjects == 0;
    }
    
    /**
     * Method to remove an object from the list at the specified index
     *
     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Lily Yang
     * @since 03/17/2024
     *
     */

    public void remove(int index) {
        shiftArrayToLeft(index);
        numObjects--;
    }
    
    /**
     * Method to return an iterator object to iterate over the elements of the list
     *
     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Lily Yang
     * @since 03/17/2024
     *
     */

    public Iterator iterator() {
        return new Iterator();
    }
    
    /**
     * Inner class representing an iterator to iterate over the elements of the list
     *
     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Lily Yang
     * @since 03/17/2024
     *
     */

    class Iterator {
        private int curr; //index of current element accessed via iterator methods

        /**
         * Method to reset the iterator to the beginning of the list
         *
         * CSC 1351 Programming Project No 1
         * Section 1
         *
         * @author Lily Yang
         * @since 03/17/2024
         *
         */
        
        public void reset() {
            curr = 0;
        }
        
        /**
         * Method to return the next object in the iteration
         *
         * CSC 1351 Programming Project No 1
         * Section 1
         *
         * @author Lily Yang
         * @since 03/17/2024
         *
         */

        public Comparable next() {
            Comparable obj = oList[curr];
            curr++;
            return obj;
        }
        
        /**
         * Method to check if there are more elements in the iteration
         *
         * CSC 1351 Programming Project No 1
         * Section 1
         *
         * @author Lily Yang
         * @since 03/17/2024
         *
         */

        public boolean hasNext() {
            return curr < numObjects;
        }
        
        /**
         * Method to remove the last element returned by the iterator from the list
         *
         * CSC 1351 Programming Project No 1
         * Section 1
         *
         * @author Lily Yang
         * @since 03/17/2024
         *
         */

        public void remove() {
            shiftArrayToLeft(curr - 1);
            numObjects--;
            curr--;
        }
    }
}