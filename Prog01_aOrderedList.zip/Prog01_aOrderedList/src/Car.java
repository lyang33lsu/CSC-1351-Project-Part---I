/**
* <Represents a Car object with properties such as make, year, & price>
*
* CSC 1351 Programming Project No 1
7
* Section 1
*
* @author Lily Yang
* @since 03/17/2024
*
*/

public class Car implements Comparable<Car> {
    private String make;
    private int year;
    private int price;

    /**
    * Constructor to initialize a Car object with make, year, & price
    *
    * CSC 1351 Programming Project No 1
    * Section 1
    *
    * @author Lily Yang
    * @since 03/17/2024
    *
    */
    
    public Car(String make, int year, int price) {
        this.make = make;
        this.year = year;
        this.price = price;
    }
    
    /**
     * Getter method to get the make of the car
     *
     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Lily Yang
     * @since 03/17/2024
     *
     */

    public String getMake() {
        return make;
    }
    
    /**
     * Getter method to get the year of the car
     *
     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Lily Yang
     * @since 03/17/2024
     *
     */

    public int getYear() {
        return year;
    }
    
    /**
     * Getter method to get the price of the car
     *
     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Lily Yang
     * @since 03/17/2024
     *
     */
    
    public int getPrice() {
        return price;
    }
    
    /**
     * Method to compare two Car objects based on their make and year
     * Returns a negative integer, zero, or a positive integer if this car is less than, equal to, or greater than the specified car
     *
     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Lily Yang
     * @since 03/17/2024
     *
     */
    
    public int compareTo(Car other) {
        if (!make.equals(other.make)) {
            return make.compareTo(other.make);
        } else {
            return Integer.compare(year, other.year);
        }
    }
    
    /**
     * Method to represent the Car object as a string
     *
     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Lily Yang
     * @since 03/17/2024
     *
     */
   
    public String toString() {
        return "Make: " + make + "\nYear: " + year + "\nPrice: $" + price + "\n";
    }
}