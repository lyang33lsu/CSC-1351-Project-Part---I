/**
* <Manages a list of cars using an ordered list>
*
* CSC 1351 Programming Project No 1
7
* Section 1
*
* @author Lily Yang
* @since 03/17/2024
*
*/

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;


public class Prog01_aOrderedList {
    public static void main(String[] args) {
        try {
            aOrderedList carList = new aOrderedList();
            Scanner inputFileScanner = GetInputFile("Enter input filename: ");
            processCarData(carList, inputFileScanner);
            inputFileScanner.close();

            PrintWriter outputFile = GetOutputFile("Enter output filename: ");
            outputList(carList, outputFile);
            outputFile.close();
            System.out.println("Output file created successfully.");
        } catch (FileNotFoundException e) {
            System.out.println("Program execution cancelled.");
        }
    }
    
    /**
     * Method to get input file from the user and return it as a Scanner object to read from that file
     *
     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Lily Yang
     * @since 03/17/2024
     *
     */

    public static Scanner GetInputFile(String userPrompt) throws FileNotFoundException {
        Scanner userInput = new Scanner(System.in);
        String fileName;
        File inputFile;

        do {
            System.out.print(userPrompt);
            fileName = userInput.nextLine().trim();
            inputFile = new File(fileName);

            if (!inputFile.exists()) {
                System.out.println("File specified <" + fileName + "> does not exist. Would you like to continue? <Y/N>");
                String response = userInput.nextLine().trim().toUpperCase();

                if (response.equals("N")) {
                    throw new FileNotFoundException();
                }
            } else {
                try {
                    return new Scanner(inputFile);
                } catch (FileNotFoundException e) {
                    System.out.println("Error opening file. Please try again.");
                }
            }
        } while (true);
    }
    
    /**
     * Method to get the output file from the user and return it as a PrintWriter object to write to that file
     *
     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Lily Yang
     * @since 03/17/2024
     *
     */

    public static PrintWriter GetOutputFile(String userPrompt) throws FileNotFoundException {
        Scanner userInput = new Scanner(System.in);
        String fileName;
        File outputFile;

        do {
            System.out.print(userPrompt);
            fileName = userInput.nextLine().trim();
            outputFile = new File(fileName);

            if (!outputFile.exists()) {
                try {
                    return new PrintWriter(outputFile);
                } catch (FileNotFoundException e) {
                    System.out.println("Error opening file. Please try again.");
                }
            } else {
                System.out.println("File specified <" + fileName + "> already exists. Would you like to continue? <Y/N>");
                String response = userInput.nextLine().trim().toUpperCase();

                if (response.equals("N")) {
                    throw new FileNotFoundException();
                }
            }
        } while (true);
    }

    /**
     * Method to process car data from input file and add/delete cars from the ordered list
     *
     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Lily Yang
     * @since 03/17/2024
     *
     */
    
    public static void processCarData(aOrderedList carList, Scanner inputFileScanner) {
        while (inputFileScanner.hasNextLine()) {
            String line = inputFileScanner.nextLine();
            String[] carData = line.split(",");

            if (carData.length > 0) {
                if (carData[0].equals("A") && carData.length == 4) {
                    String make = carData[1];
                    int year = Integer.parseInt(carData[2]);
                    int price = Integer.parseInt(carData[3]);

                    Car newCar = new Car(make, year, price);
                    carList.add(newCar);
                } else if (carData[0].equals("D") && carData.length == 3) {
                    String make = carData[1];
                    int year = Integer.parseInt(carData[2]);

                    carList.delete(make, year);
                }
            }
        }
    }
    
    /**
     * Method to output the sorted list of cars to the output file
     *
     * CSC 1351 Programming Project No 1
     * Section 1
     *
     * @author Lily Yang
     * @since 03/17/2024
     *
     */

    public static void outputList(aOrderedList carList, PrintWriter outputFile) {
        outputFile.println("Number of cars: " + carList.size());

        aOrderedList.Iterator iter = carList.iterator();
        while (iter.hasNext()) {
            Car car = (Car) iter.next();
            outputFile.println(car);
        }
    }
}